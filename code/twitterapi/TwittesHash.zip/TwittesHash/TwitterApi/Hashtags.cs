﻿using System.Collections.Generic;
using System.Runtime.Serialization;

namespace VolgaLabs.TwitterApi {
	[DataContract]
	public class Hashtags {
		[DataMember]
		public List<int> indicies;

		[DataMember]
		public string text;
	}
}
