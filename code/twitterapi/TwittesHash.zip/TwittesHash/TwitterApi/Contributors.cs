﻿using System.Runtime.Serialization;

namespace VolgaLabs.TwitterApi
{
	[DataContract]
	public class Contributors {
		[DataMember]
		public long id;

		[DataMember]
		public string id_str;

		[DataMember]
		public string screen_name;
	}
}
