﻿using System.Runtime.Serialization;

namespace VolgaLabs.TwitterApi {
	[DataContract]
	public class CurrentUserRetweet {
		[DataMember]
		public long id;

		[DataMember]
		public string id_str;
	}
}
