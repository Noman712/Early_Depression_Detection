﻿using System.Collections.Generic;
using System.Runtime.Serialization;

namespace VolgaLabs.TwitterApi 
{
	[DataContract]
	public class BoundingBox {
		[DataMember]
		public List<List<List<double>>> coordinates;

		[DataMember]
		public string type;
	}
}
