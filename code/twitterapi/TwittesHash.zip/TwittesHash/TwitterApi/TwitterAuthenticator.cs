﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Web.Script.Serialization;

namespace VolgaLabs.TwitterApi
{

    public class TwitterAuthenticator : IDisposable
    {
        private const string BaseAuthUrl = "https://api.twitter.com/oauth2/token";
        private const string BaseSearchUrl = "https://api.twitter.com/1.1/search/tweets.json";
        private const string BaseInvalidateUrl = "https://api.twitter.com/oauth2/invalidate_token";
        private const string BaseUserUrl = "https://api.twitter.com/1.1/statuses/user_timeline.json";

        private readonly AccessToken _credentials;
        private readonly string _bearerTokenCredentials;

        public TwitterAuthenticator(string p_ConsumerKey, string p_ConsumerSecret)
        {
            _bearerTokenCredentials =
                Convert.ToBase64String(
                    Encoding.ASCII.GetBytes(
                        string.Format("{0}:{1}",
                            Uri.EscapeUriString(p_ConsumerKey),
                            Uri.EscapeUriString(p_ConsumerSecret))));

            var request = WebRequest.Create(BaseAuthUrl) as HttpWebRequest;

            if (request != null)
            {
                request.KeepAlive = false;
                request.Method = "POST";
                request.Headers.Add("Authorization", string.Format("Basic {0}", _bearerTokenCredentials));
                request.ContentType = "application/x-www-form-urlencoded;charset=UTF-8";

                var content = Encoding.ASCII.GetBytes("grant_type=client_credentials");
                using (var stream = request.GetRequestStream())
                    stream.Write(content, 0, content.Length);

                HttpWebResponse response = request.GetResponse() as HttpWebResponse;

                DataContractJsonSerializer accessTokenJsonSerializer =
                    new DataContractJsonSerializer(typeof(AccessToken));
                if (response != null)
                    _credentials = (AccessToken) accessTokenJsonSerializer.ReadObject(response.GetResponseStream());
            }
        }

        public List<Tweet> GetTweetsByUser(string screenName, int count)
        {
            var request = GetWebRequestForUserTweets(screenName, count);
            return GetUserTweets(request, count);
        }

        public List<Tweet> GetTweetsByTag(string query, int count)
        {
            var request = GetWebRequestForTweets(query, count);
            return GetTweets(request, count);
        }

        private HttpWebRequest GetWebRequestForTweets(string p_Query, int count)
        {
            var request =
                WebRequest.Create(string.Format("{0}?q={1}&result_type=recent&count={2}", BaseSearchUrl, p_Query, count))
                    as HttpWebRequest;
            if (request != null)
            {
                request.Headers.Add("Authorization", string.Format("Bearer {0}", _credentials.access_token));
                request.KeepAlive = false;
                request.Method = "GET";
                return request;
            }

            return null;
        }

        private HttpWebRequest GetWebRequestForUserTweets(string screenName, int count = 200)
        {
            var request =
                WebRequest.Create(string.Format("{0}?screen_name={1}&count={2}", BaseUserUrl, screenName, count)) as
                    HttpWebRequest;
            if (request != null)
            {
                request.Headers.Add("Authorization", string.Format("Bearer {0}", _credentials.access_token));
                request.KeepAlive = false;
                request.Method = "GET";
                return request;
            }

            return null;
        }

        private List<Tweet> GetUserTweets(HttpWebRequest webRequest, int count)
        {
            string resultString;

            var returnValue = new List<Tweet>();
            try
            {
                var request = webRequest;

                var response = request.GetResponse() as HttpWebResponse;
                using (var sd = new StreamReader(response.GetResponseStream()))
                {
                    resultString = sd.ReadToEnd();
                    response.Close();
                }

                JavaScriptSerializer serializer = new JavaScriptSerializer();
                IEnumerable<Tweet> twitterResults = serializer.Deserialize<IEnumerable<Tweet>>(resultString);

                if (twitterResults != null)
                {
                    returnValue.AddRange(twitterResults);
                }
            }
            catch (Exception)
            {
                
            }
           
            return returnValue;
        }

        private List<Tweet> GetTweets(HttpWebRequest webRequest, int count)
        {
            var returnValue = new List<Tweet>();
            try
            {
                var jsonSerializer = new DataContractJsonSerializer(typeof(TwitterResults));

                var request = webRequest;

                var response = request.GetResponse() as HttpWebResponse;
                var twitterResults = (TwitterResults) jsonSerializer.ReadObject(response.GetResponseStream());
                if (twitterResults.statuses != null)
                {
                    returnValue.AddRange(twitterResults.statuses);

                    while (!string.IsNullOrWhiteSpace(twitterResults.search_metadata.next_results) &&
                           returnValue.Count < count)
                    {
                        request =
                            WebRequest.Create(string.Format("{0}{1}", BaseSearchUrl,
                                twitterResults.search_metadata.next_results)) as HttpWebRequest;
                        if (request != null)
                        {
                            request.Headers.Add("Authorization", string.Format("Bearer {0}", _credentials.access_token));
                            request.KeepAlive = false;
                            request.Method = "GET";

                            response = request.GetResponse() as HttpWebResponse;
                        }
                        if (response != null)
                            twitterResults = (TwitterResults) jsonSerializer.ReadObject(response.GetResponseStream());
                        returnValue.AddRange(twitterResults.statuses);
                    }
                }
            }
            catch (Exception)
            {
                
            }
            
            
            return returnValue;
        }

        public void Dispose()
        {
            HttpWebRequest request = WebRequest.Create(BaseInvalidateUrl) as HttpWebRequest;
            if (request != null)
            {
                request.KeepAlive = false;
                request.Method = "POST";
                request.Headers.Add("Authorization", string.Format("Basic {0}", _bearerTokenCredentials));
                request.ContentType = "application/x-www-form-urlencoded";

                byte[] content = Encoding.ASCII.GetBytes(string.Format("access_token={0}", _credentials.access_token));
                using (Stream stream = request.GetRequestStream())
                    stream.Write(content, 0, content.Length);

                try
                {
                    request.GetResponse();
                }
                catch
                {
                    // The bearer token will time out if this fails.
                }
            }
        }
    }
}
