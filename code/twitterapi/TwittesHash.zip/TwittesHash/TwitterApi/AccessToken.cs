﻿using System.Runtime.Serialization;

namespace VolgaLabs.TwitterApi 
{
	[DataContract]
	public class AccessToken {
		[DataMember]
		public string token_type;

		[DataMember]
		public string access_token;
	}
}
