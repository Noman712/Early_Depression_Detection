﻿using DBLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using System.Web.UI.WebControls.Expressions;
using VolgaLabs.TwitterApi;
using Tweet = VolgaLabs.TwitterApi.Tweet;

namespace TwittesHash.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            ViewBag.Message = "Modify this template to jump-start your ASP.NET MVC application.";

            return View();
        }

        public ActionResult TweetsByHashTag()
        {
            TwitterDB db = new TwitterDB();
            List<Tweet> tweets = db.GetAllTweets();
            return View("TweetsByHashTag", tweets);
        }

        public ActionResult UserTweets(string id)
        {
            TwitterDB db = new TwitterDB();
            List<Users> users = db.GetAllTwitterUsers();

            users = users.OrderBy(o => o.screen_name).ToList();
            ViewBag.users = users;
            if (string.IsNullOrEmpty(id))
            {
                return View("UserTweets");
            }
            long longId = Convert.ToInt64(id);
            List<Tweet> tweets = db.GetAllTweetsByUser(longId);
            TwitterUser user = db.GetUser(longId);

            ViewBag.ScreenName = user.user_screenname;
            return View("UserTweets", tweets);
        }

        [HttpPost]
        public JsonResult SaveSearch(string generationID)
        {
            TwitterDB db = new TwitterDB();
            bool result = db.SaveSearch(generationID);
            return Json(new { result = result });
        }

        [HttpPost]
        public JsonResult DiscardSearch(string generationID)
        {
            TwitterDB db = new TwitterDB();
            bool result = db.SaveSearch(generationID, false);
            return Json(new { result = result });
        }

        public ActionResult Search()
        {
            ViewBag.Message = "Modify this template to jump-start your ASP.NET MVC application.";

            return View("Index");
        }

        [HttpPost]
        public ActionResult Search(FormCollection forms)
        {
            string nameToSearch = forms["hashtag"];
            List<VolgaLabs.TwitterApi.Tweet> tweets = new List<Tweet>();
            string formCount = forms["count"];
            int count;
            int.TryParse(formCount, out count);
            string radioButtonName = forms["SearchType"];
            TwitterAuthenticator twitterAuthenticator = new TwitterAuthenticator(AuthConfig.ConsumerKey, AuthConfig.ConsumerSecret);
            if (radioButtonName.Equals("hashtag", StringComparison.InvariantCulture))
            {
                string hashTag = "#ACME"; //default hash tag
                if (nameToSearch != string.Empty)
                {
                    nameToSearch = nameToSearch.Replace("#", "");
                    nameToSearch = nameToSearch.Replace(" ", "");
                    hashTag = nameToSearch;
                }
                else
                {
                    ViewBag.Error = "Kindly Enter hashtag you want to search.";
                    return View("Index");
                }

                tweets = twitterAuthenticator.GetTweetsByTag(hashTag, count);
                if (tweets.Count > 0)
                {
                    Guid generationID = Guid.NewGuid();

                    TwitterDB db = new TwitterDB();
                    db.SaveTweetsAsync(tweets, generationID, VolgaLabs.TwitterApi.SearchType.Hashtag.ToString(), nameToSearch);

                    ViewBag.generationID = generationID;
                }
                ViewBag.SelectedAction = "hashtag";
            }
            else if (radioButtonName.Equals("query", StringComparison.InvariantCulture))
            {
                string hashTag = "#ACME"; //default hash tag
                if (nameToSearch != string.Empty)
                {
                    hashTag = nameToSearch;
                }
                else
                {
                    ViewBag.Error = "Kindly Enter hashtag you want to search.";
                    return View("Index");
                }

                tweets = twitterAuthenticator.GetTweetsByTag(hashTag, count);
                if (tweets.Count > 0)
                {
                    Guid generationID = Guid.NewGuid();

                    TwitterDB db = new TwitterDB();
                    db.SaveTweetsAsync(tweets, generationID, VolgaLabs.TwitterApi.SearchType.Hashtag.ToString(), nameToSearch);

                    ViewBag.generationID = generationID;
                }
                ViewBag.SelectedAction = "query";
            }
            else
            {
                string userName = "saurabh"; //default name
                if (nameToSearch != string.Empty)
                {
                    userName = nameToSearch;
                }

                tweets = twitterAuthenticator.GetTweetsByUser(userName, count);

                if (tweets.Count > 0)
                {
                    Guid generationID = Guid.NewGuid();

                    TwitterDB db = new TwitterDB();
                    db.SaveTweetsAsync(tweets, generationID, VolgaLabs.TwitterApi.SearchType.User.ToString(), nameToSearch);

                    ViewBag.generationID = generationID;
                }
                ViewBag.SelectedAction = "user";
            }
            
            ViewBag.hashtag = nameToSearch;
            ViewBag.count = count;
            return View("Index", tweets);
        }

        [HttpPost]
        public ActionResult UserTweetsSearch(FormCollection forms)
        {
            string formusername = forms["username"];

            string formCount = forms["count"];
            int count;
            int.TryParse(formCount, out count);

            string userName = "saurabh"; //default name
            if (formusername != string.Empty)
            {
                userName = formusername;
            }

            TwitterAuthenticator twitterTool1 = new TwitterAuthenticator(AuthConfig.ConsumerKey, AuthConfig.ConsumerSecret);
            List<VolgaLabs.TwitterApi.Tweet> tweets = twitterTool1.GetTweetsByUser(userName, count);

            ViewBag.username = formusername;

            return View("UserTweets", tweets);
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your app description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}
