﻿$(document).ready(function () {

    var error = function (err, response, body) {
        console.log('ERROR [%s]', err);
    };
    var success = function (data) {
        console.log('Data [%s]', data);
    };

    function load()
    {
        //var Twitter = require('twitter-node-client').Twitter;

        //var twitter = new Twitter();

        //twitter.getSearch({ 'q': '#haiku', 'count': 10 }, error, success);

        var key = encodeURI("62447562-pV7y3DRpfduzS330Xev1VdV5qOjyvfygm3qkAVdJN");
        var sccrfet = encodeURI("cfctYsI5HklUjPdiPCqcS6T5Y8iFgITmiurlQWq5hCnHa");
        var basestring=btoa(key + ":" + sccrfet);

            //$.ajax({
            //    type: "GET", 
            //    url: "https://api.twitter.com/oauth2/token?grant_type=client_credentials",
            //    data: { "Authorization": "Basic " + basestring },
            //    success: function (data) {
                 

                   

            //    },
            //    dataType: 'json'
            //});

            $.ajax({
                type: "GET",
                url: "https://api.twitter.com/1.1/search/tweets.json?q=%23QuanticoMondays",
                data: { "token_type": "bearer", "access_token": "cfctYsI5HklUjPdiPCqcS6T5Y8iFgITmiurlQWq5hCnHa" },
                success: function (data) {




                },
                dataType: 'json'
            });
           
        //$.get("https://api.twitter.com/1.1/search/tweets.json?q=%23QuanticoMondays&access_token=cfctYsI5HklUjPdiPCqcS6T5Y8iFgITmiurlQWq5hCnHa", null, function (data, stat, xdata) {

        //        if (data) {
        //        }

        //    }, "json");
       

           
    }

    load();

});