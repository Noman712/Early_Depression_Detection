 
require(["Twitter"], function (Twitter) {
     

    var twitter = new Twitter();

    twitter.getSearch({ 'q': '#haiku', 'count': 10 }, error, success);

});
//$(document).ready(function () {

//    var error = function (err, response, body) {
//        console.log('ERROR [%s]', err);
//    };
//    var success = function (data) {
//        console.log('Data [%s]', data);
//    };

//    function load() {
//        var Twitter = require('Twitter').Twitter;

//        var twitter = new Twitter();

//        twitter.getSearch({ 'q': '#haiku', 'count': 10 }, error, success);

//        //var key = encodeURI("xg30HVS48w8RG8sLGlMMLo54e");
//        //var sccrfet = encodeURI("xJJr9L4Z855na7jxritjudLv2F1aczl3a3aGh88yseAERfoVz2");
//        //var basestring=btoa(key + ":" + sccrfet);

//        //    $.ajax({
//        //        type: "POST", 
//        //        url: "https://api.twitter.com/oauth2/token?grant_type=client_credentials",
//        //        data: { "Authorization": "Bearer "+basestring },
//        //        success: function (data) {
//        //            $.get("https://api.twitter.com/1.1/search/tweets.json?q=%23QuanticoMondays&access_token=62447562-pV7y3DRpfduzS330Xev1VdV5qOjyvfygm3qkAVdJN", null, function (data, stat, xdata) {

//        //                if (data) {
//        //                }

//        //            }, "json");



//        //        },
//        //        dataType: 'json'
//        //    });





//    }

//    load();

//});